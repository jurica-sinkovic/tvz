<?php 

//autogeneriranje lozinke od 8 znakova (random slova i znakovi)
$pwd = bin2hex(openssl_random_pseudo_bytes(4));

	if ($_POST['_action_'] == FALSE) {
		print '

	<!-- Page Content -->
    <div class="container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="text-center">


							<h3><i class="fa fa-user fa-4x"></i></h3>
							<h2 class="text-center">Registracija</h2>
							<div class="panel-body">
								
								<form action="" id="registration_form" name="registration_form" method="POST">
								<input type="hidden" id="_action_" name="_action_" value="TRUE">

									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-tag"></i></span>

											<input id="firstname" name="firstname" type="text" oninput="generateUsername()" class="form-control" placeholder="Ime" required>';
											?>

										<script type="text/javascript">
										// Samo za prikaz, prava funkcija je napisan u PHP (treba je pretvoriti u JS ili pozvati po slanju - autoun.php)
										
										   function generateUsername()
										   {
											var first = document.getElementById("firstname").value.charAt(0).toLowerCase();
											var second = document.getElementById("lastname").value.toLowerCase();
											document.getElementById("username").value = first+""+second;
										   }
										</script>
											<?php 
											print '
										</div>
									</div>

									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-tags"></i></span>
											
											<input name="lastname" type="text" id="lastname" oninput="generateUsername()" class="form-control" placeholder="Prezime" required>
										</div>
									</div>
									
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>';
											?>								
											<input type="text" name="dob" placeholder="Datum rođenja" class="form-control"  onfocus="(this.type='date')" onblur="if(this.value==''){this.type='text'}" required>
											<?php 
											print'
										</div>
									</div>
									
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>

											<input name="email" type="email" class="form-control" placeholder="Email" required>
										</div>
									</div>
									
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>

											<input name="username" id="username" type="text" class="form-control" placeholder="Korisničko ime"  required>
										</div>
									</div>

									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
											<!-- Lozinka se automatski generira pseudo-random stringom - 4 znaka u varijabli $psw, te je u text obliku da je korisnik vidi  -->
											<input name="password" type="text" class="form-control" placeholder="Lozinka" value="'; echo $pwd; print '" required>
										</div>
									</div>
									

									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-globe"></i></span>
											
											<select name="country" class="form-control" required>
											 <option value="">Država</option>';
											  $query  = "SELECT * FROM countries";
												$result = @mysqli_query($MySQL, $query);
												while($row = @mysqli_fetch_array($result)) {
													print '<option value="' . $row['country_code'] . '">' . $row['country_name'] . '</option>';
												}
											print '
											</select>
											
										</div>
									</div>
								
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-circle-arrow-right"></i></span>
											
											<input name="city" type="text" class="form-control" placeholder="Grad" required>
										</div>
									</div>
									
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-arrow-right"></i></span>
											
											<input name="street" type="text" class="form-control" placeholder="Ulica" required>
										</div>
									</div>
								
									<div class="form-group">
										<input name="login" class="btn btn-lg btn-primary btn-block" value="Registriraj se" type="submit">
									</div>
								</form>
							</div>';
										
					}
					else if ($_POST['_action_'] == TRUE) {
						
					$query  = "SELECT * FROM users";
					$query .= " WHERE email='" .  $_POST['email'] . "'";
					$query .= " OR username='" .  $_POST['username'] . "'";
					$result = @mysqli_query($MySQL, $query);
					$row = @mysqli_fetch_array($result, MYSQLI_ASSOC);
					
					if ($row['email'] == '' || $row['username'] == '') {
						# password_hash https://secure.php.net/manual/en/function.password-hash.php
						# password_hash() creates a new password hash using a strong one-way hashing algorithm
						$pass_hash = password_hash($_POST['password'], PASSWORD_DEFAULT, ['cost' => 12]);
						
						$query  = "INSERT INTO users (firstname, lastname, email, username, password, country, city, street, dob)";
						$query .= " VALUES ('" . $_POST['firstname'] . "', '" . $_POST['lastname'] . "', '" . $_POST['email'] . "', '" . $_POST['username'] . "', '" . $pass_hash . "', '" . $_POST['country'] . "', '" . $_POST['city'] . "', '" . $_POST['street'] . "', '" . $_POST['dob'] . "')";
						$result = @mysqli_query($MySQL, $query);
								
						
						# ucfirst() — Make a string's first character uppercase
						# strtolower() - Make a string lowercase
						echo '<div class="alert alert-success"><strong>' . ucfirst(strtolower($_POST['firstname'])) . ' ' .  ucfirst(strtolower($_POST['lastname'])) . '</strong>, hvala Vam na registraciji.</div>';
					}
					else {
						echo '<div class="alert alert-danger">Korisnik s navedenim korisničkim imenom ili email adresom već <strong>postoji</strong>!</div>';
					}
				}
				print '

						</div>
					</div> <!-- End panel Body-->
				</div>
			</div>
		</div>
		<hr>	
	</div>';
	
?>