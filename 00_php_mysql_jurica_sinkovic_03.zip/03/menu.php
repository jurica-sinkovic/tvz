<?php 

print '

    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
			<div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Navigacija</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php?menu=1">Početna stranica</a>
            </div>
			
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php?menu=2">Novosti</a>
                    </li>
                    <li>
                        <a href="index.php?menu=3">Kontakt</a>
                    </li>
                    <li>
                        <a href="index.php?menu=4">O nama</a>
                    </li>
                    <li>
                        <a href="index.php?menu=5">Galerija</a>
                    </li>';
					
					if (!isset($_SESSION['user']['valid']) || $_SESSION['user']['valid'] == 'false') {
					print '
					<li>
						<a href="index.php?menu=6">Registracija</a>
					</li>
					<li>
						<a href="index.php?menu=7">Prijava</a>
					</li>';
					
					}
					else if ($_SESSION['user']['valid'] == 'true') {
						print '
						<li>
							<a href="index.php?menu=8">Admin</a>
						</li>
						<li>
							<a href="odjava.php">Odjava</a>
						</li>';
					}
					print '
                </ul>
            </div>
        </div>
    </nav>
	<br>';
?>