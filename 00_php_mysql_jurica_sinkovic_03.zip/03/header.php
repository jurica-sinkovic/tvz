<?php 

print '

<!DOCTYPE html>
<html>

<head>

	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta name="description" content="Sustav za praćenje vatrogasnih aktivnosti">
	<meta name="keywords" content="Vatrogasci, VZOKT, CMS">
	<meta name="author" content="Jurica Sinković">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="shortcut icon" type="image/x-icon" href="images/fav_icon.png"">

	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet"/>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
	
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/map.css" rel="stylesheet">
	
	<title>CMS sustav Vatrogasne zajednice općine Krapinske Toplice</title>
	
</head>

<body>';

?>