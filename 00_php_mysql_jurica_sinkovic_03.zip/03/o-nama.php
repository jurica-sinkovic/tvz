<?php 
	print '
	
	<!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">O nama<br></h1>

                <h4>Vatrogasna zajednica općine Krapinske Toplice osnovana je 24.05.1993. godine u prostorijama DVD-a Krapinske Toplice.</h4>
                <hr>

                <p>Službene prostorije ima u prostorima DVD Krapinske Toplice. VZOKT ima svoju Internet stranicu na kojoj se mogu naći svi podaci svih društava u zajednici, u zajednici ima 5 DVD-a:</p>
                <ul>
                <li>Krapinske Toplice,</li>
                <li>Mala Erpenja,</li>
                <li>Čret,</li>
                <li>Selno i</li>
                <li>Specijalna Bolnica</li>
                </ul>
                <br />
				
				<video width="100%" controls poster="images/vzokt_logo_png.png" >
				  <source src="video/fire_nogomet.mp4" type="video/mp4">
				  Your browser does not support HTML5 video.
				</video>

                <br />

                <p>Statistički gledano u zajednici djeluje i radi: 450 vatrogasaca, djece, mladeži, žena, pričuvnih, veterana i podupirajučih članova. Predsjedništvo broji 11 članova, Skupština broji 27 članova VZOKT. Sjednice PZ, NO, zapovjedništva, voditelja djece i mladeži održavaju se po potrebi.</p>
                <p>VZOKT organizira svake godine sv. misu povodom Sv. Florjana u Krapinskim Toplicama, Suorganizacija natjecanja memorijala Marije Badl, djece i mladeži, kup DVD Mala Erpenja. Zapovjedništvo daje upute o nabavci opreme za sve DVD-e u VZOKT, te nabavka potrebnih vatrogasnih vozila, u zadnje vrijeme nabavljena su 2 vozila Unimog DVD Čret šumsko vozilo i DVD M. Erpenja, navalno vozilo, te novi kombi vozilo za DVD Selno, te rabljeno kombi vozilo za DVD Mala Erpenja i DVD Čret.</p>
                <p>VZOKT organizira osposobljavanje, nadzor nad DVD-ima provodi preventivu, organizira pokazne vježbe, educira svoje operativne članove, organizira operativne vježbe, u zajednici djeluje Odbor savjeta voditelja koji potiče rad sa<br />
                djecom i mladeži, sudjeluje u očuvanju našeg okoliša. Vrši predavanje pravnim osobama pri ispunjenju zakonske obaveze za provedbu mjera zaštite od požara i spašavanja ljudi i imovine. Kao i u slučaju elementarnih nepogoda pružiti pučanstvu potrebnu pomoć kao i domaćinstvima dovoziti vodu prema potrebi. Uzbunjivanje u općini Krapinske Toplice vrši se dojavom VOC-a ili DUZS uklopom sirena od kojih DVD Krapinske Toplice imaju instaliran daljinski uklop. Zajednica se financira iz proračuna općine Krapinske Toplice, te raznih donacija.</p>
                <p>Vatrogasni pomladak je potreban ne samo reda, radi već zbog članova koji će ostati u vatrogasnom društvu cijeli svoj život, od djece, mladeži, mladih vatrogasaca, operativnih članova do vodećih ljudi u DVD u. i zajednici. U našoj vatrogasnoj zajednici općine Krapinske Toplice u DVD-ima prepoznali su potrebu i ustrojili rad sa djecom i mladeži, Odbor savjeta voditelja VZOKT potiče rad sa mladima.</p>

            </div>';

        include("sidebar.php");
		print '
        </div>
        <!-- /.row -->

        <hr>

    </div>';
	
	
?>