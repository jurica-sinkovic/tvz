<?php 

print '
	<!-- Blog Sidebar Widgets Column -->
    <div class="col-md-4">

        <!-- Novosti -->
        <div class="well">
                <h4>Novosti</h4>';
		
				$query  = "SELECT * FROM news";
				$query .= " ORDER BY date DESC";
				$result = @mysqli_query($MySQL, $query);
				while($row = @mysqli_fetch_array($result)) {
					print '
					<span>';
							if ($row['archive'] == 'Y') { print '<span class="glyphicon glyphicon-ok"></span>'; }
                            else if ($row['archive'] == 'N') { print '<span class="glyphicon glyphicon-remove"></span>'; }
						print '
						</span>
						<span>' . $row['title'] . '</span>
						<br>';
				}
				
			print '<br>
					
				<p>Novosti označene kvačicom <span class="glyphicon glyphicon-ok"></span> čekaju <strong>odobrenje</strong> od strane administratora.</p>
            </div>

         <!-- Korisnici -->
            <div class="well">
                <h4>Korisnici</h4>';
		
				$query  = "SELECT * FROM users";
				$result = @mysqli_query($MySQL, $query);
				while($row = @mysqli_fetch_array($result)) {
					print '					
						<span>';
							if ($row['role'] > 0) { print '<span class="glyphicon glyphicon-remove"></span>'; }
                            else if ($row['role'] == 0) { print '<span class="glyphicon glyphicon-ok"></span>'; }
						print '
						</span>
						<span>' . $row['firstname'] . '</span>
						<span>' . $row['lastname'] . ' - </span>
						<span>' . $row['email'] . '</span>
						<br>';
				}
				
			print '<br>
					
				<p>Korisnici označeni kvačicom <span class="glyphicon glyphicon-ok"></span> su <strong>novi i čekaju definiranje prava pristupa</strong> od strane administratora.</p>
            </div>

    </div>';
?>