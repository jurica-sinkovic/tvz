<?php 
	function pickerDateToMysql($pickerDate){
		$date = DateTime::createFromFormat('Y-m-d H:i:s', $pickerDate);
		return $date->format('d.m.Y H:i:s');
	}  
	
	function pickerDate($datum){
		$date = DateTime::createFromFormat('Y-m-d', $datum);
		return $date->format('d.m.Y');
	}  

?>