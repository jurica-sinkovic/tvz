<?php
	# Stop Hacking attempt
    define('__APP__', TRUE);

	# Start session
	session_start();
	
	
	unset($_POST);
	unset($_SESSION['user']);

	$_SESSION['user']['valid'] = 'false';
	$_SESSION['message'] = '<div class="alert alert-info">Uspješno ste odjavljeni, ukoliko želite uređivati sadržaj molimo Vas da se ponovo <strong>prijavite</strong>.</div>';
	
	header("Location: index.php?menu=1");
	exit;