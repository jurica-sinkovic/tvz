<?php 
	if ($_SESSION['user']['valid'] == 'true') {
		if (!isset($action)) { $action = 1; }
		print '
		
	<!-- Page Content -->
		<div class="container">

			<div class="row">

				<!-- Blog Entries Column -->
				<div class="col">
					<h1 class="page-header">Administracija</h1>
				   
				<div class="navbar navbar-inverse">
					<ul class="nav navbar-nav">
						<li><a href="index.php?menu=8&amp;action=1">Korisnici</a></li>
						<li><a href="index.php?menu=8&amp;action=2">Novosti</a></li>
					</ul>
				</div>';
				
			# Ako je Administrator vidi oboje
			if ($_SESSION['user']['role'] == 1) {
				# Admin Users	
				if ($action == 1) { include("admin/korisnici.php"); }
				# Admin News
				else if ($action == 2) { include("admin/novosti.php"); }
			}
			
			# Ako je Editor vidi samo novosti
			if ($_SESSION['user']['role'] == 2 OR $_SESSION['user']['role'] == 3) {
				# Admin News
				if ($action == 2) { include("admin/novosti.php"); }
				}
			
			# Ako je neodobreni korisnik ne vidi ništa
			if ($_SESSION['user']['role'] == 0) {
				$_SESSION['message'] = '<div class="alert alert-danger">Nemate <strong>pravo pristupa</strong> administrativnom dijelu!</div>';
				header("Location: index.php?menu=7");
			}
			
			
	}
	else {
		$_SESSION['message'] = '<div class="alert alert-danger"><strong>Registrirajte se ili prijavite</strong> svojim korisničkim podacima za pristup administrativnom dijelu.</div>';
		header("Location: index.php?menu=7");
	}
	print '
	
	

		</div>
     </div>
     <hr>

    </div>';
	
?>