<?php 
	print '
	
	<!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">Galerija<br>
                    <small>Prikaz slika s operativne vježbe.</small>
                </h1>
                <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_10.jpg">
                    <img src="images/galerija_10.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Spajanje autocisterne na hidrant.</figcaption>
                    </div>
                    </a>
                </figure>
                </div>


                <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_11.jpg">
                    <img src="images/galerija_11.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Dolazak navalnog vozila DVD Čret.</figcaption>
                    </div>
                    </a>
                </figure>
                </div>  

                  <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_03.jpg">
                    <img src="images/galerija_03.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Autoljestve ZJVP.</figcaption>
                    </div>
                    </a>
                </figure>
                </div> 

                  <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_04.jpg">
                    <img src="images/galerija_04.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Opremanje navalne grupe.</figcaption>
                    </div>
                    </a>
                </figure>
                </div> 

                 <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_05.jpg">
                    <img src="images/galerija_05.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Unutarnja navala.</figcaption>
                    </div>
                    </a>
                </figure>
                </div> 

                  <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_06.jpg">
                    <img src="images/galerija_06.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Spašavanje unesrećenih.</figcaption>
                    </div>
                    </a>
                </figure>
                </div> 

                  <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_07.jpg">
                    <img src="images/galerija_07.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Vanjska navala autoljestvama.</figcaption>
                    </div>
                    </a>
                </figure>
                </div> 

                <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_08.jpg">
                    <img src="images/galerija_08.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Evakuacija stanara.</figcaption>
                    </div>
                    </a>
                </figure>
                </div> 


                  <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_09.jpg">
                    <img src="images/galerija_09.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Gašenje vanjskom navalom.</figcaption>
                    </div>
                    </a>
                </figure>
                </div> 


                  <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_01.jpg">
                    <img src="images/galerija_01.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Opremanje vodne grupe.</figcaption>
                    </div>
                    </a>
                </figure>
                </div> 

                 <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_02.jpg">
                    <img src="images/galerija_02.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Primanje zapovijedi.</figcaption>
                    </div>
                    </a>
                </figure>
                </div> 

                 <div class="col-sm-4">
                <figure>
                    <a href="images/galerija_12.jpg">
                    <img src="images/galerija_12.jpg" alt="Lights" style="width:100%">
                    <div class="caption">
                      <figcaption>Postrojavanje.</figcaption>
                    </div>
                    </a>
                </figure>
                </div> 

            <hr>

            </div>';

        include("sidebar.php");
		print '
        </div>
        <!-- /.row -->

        <hr>

    </div>';
	
	
?>