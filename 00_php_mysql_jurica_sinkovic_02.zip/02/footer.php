<?php 

print '

</main>

	<footer class="footer">
	  <div class="container text-center">
		Copyright &copy; ' . date("Y") . '. Jurica Sinković | Sva prava pridržana.<br>
		<a href="mailto:jsinkovic@tvz.hr"><i class="fas fa-envelope"></i> Email</a> | 
		<a target="_blank" href="https://github.com/jurica-sinkovic"><i class="fab fa-github"></i> GitHub</a>
	  </div>
	</footer>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>
</html>';

?>