<?php 
	print '
	
	<!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">Novosti<br>
                    <small>Kronološki prikaz najnovijih objava.</small>
                </h1>

                <!-- 1 Blog Post -->
                <h2>
                    <a href="#">Vježba 1.</a>
                </h2>
                <p class="lead">
                    Autor: <a href="#">Jurica</a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> 05.10.2018</p>
                    <a target="_blank" href="#">
                      <img class="img-responsive" src="images/novosti_1.jpg" alt="Vježba 1">
                    </a>
                <p>Svaki DVD mora sudjelovati sa najmanje 5 članova...</p>
                <a class="btn btn-primary" href="#">Više <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>

                <!-- 2 Blog Post -->
                <h2>
                    <a href="#">Vježba 2.</a>
                </h2>
                <p class="lead">
                    Autor: <a href="#">Jurica</a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> 04.10.2018</p>
                    <a target="_blank" href="#">
                      <img class="img-responsive" src="images/novosti_2.jpg" alt="Vježba 2">
                    </a>
                <p>Detalji taktičkih zadataka (i demonstracija) će biti...</p>
                <a class="btn btn-primary" href="#">Više <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>

                <!-- 3 Blog Post -->
                <h2>
                    <a href="#">Vježba 3.</a>
                </h2>
                <p class="lead">
                    Autor: <a href="#">Jurica</a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> 03.10.2018</p>
                    <a target="_blank" href="#">
                      <img class="img-responsive" src="images/novosti_3.jpg" alt="Vježba 3">
                    </a>
                <p>Sve vježbe izvode se na istome mjestu i sa istom opremom...</p>
                <a class="btn btn-primary" href="#">Više <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>


                <!-- 4 Blog Post -->
                <h2>
                    <a href="#">Vježba 4.</a>
                </h2>
                <p class="lead">
                    Autor: <a href="#">Jurica</a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> 02.10.2018</p>
                    <a target="_blank" href="#">
                      <img class="img-responsive" src="images/novosti_4.jpg" alt="Vježba 4">
                    </a>
                <p>Taktički zadaci su koncipirani na način da su izazovni...</p>
                <a class="btn btn-primary" href="#">Više <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>


                <!-- 5 Blog Post -->
                <h2>
                    <a href="#">Vježba 5.</a>
                </h2>
                <p class="lead">
                    Autor: <a href="#">Jurica</a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> 01.10.2018</p>
                    <a target="_blank" href="#">
                      <img class="img-responsive" src="images/novosti_5.jpg" alt="Vježba 5">
                    </a>
                <p>Vježbu nadziru zapovjednik VZKZŽ, zapovjednik i zamjenik VZOKT.</p>

                <a class="btn btn-primary" href="#">Više <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>';
				include("pager.php");	
			print '	
			</div>';
		
		
        include("sidebar.php");
		print '
        </div>
        <!-- /.row -->

        <hr>

    </div>';
	
	
?>