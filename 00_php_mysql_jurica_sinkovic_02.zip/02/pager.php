<?php 

print '
	<!-- Pager -->
		<ul class="pager">
			<li class="previous">
				<a href="#">&larr; Starije</a>
			</li>
			<li class="next">
				<a href="#">Novije &rarr;</a>
			</li>
		</ul>';
?>