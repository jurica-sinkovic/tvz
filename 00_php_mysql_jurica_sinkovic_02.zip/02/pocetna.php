<?php 
	print '
	
	<!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">Dobrodošli!</h1>

                <!-- First Blog Post -->
                <h2>Vatrogasna zajednica općine Krapinske Toplice.</h2>

                <hr>
				
                <img src="images/vzokt_logo_png.png" class="figure-img img-fluid rounded" alt="Vatrogasna zajednica općine Krapinske Toplice.">
				<figcaption class="figure-caption">Vatrogasna zajednica općine Krapinske Toplice.</figcaption>
				
                <hr>
				
                <p>Kako bi što kvalitetnije prezentirali nove obavijesti i zbivanja na području Vatrogasne zajednice općine Krapinske Toplice i njihovih članica DVD-a (Krapinske Toplice, Mala Erpenja, Čret, Selno i Specijalna Bolnica) izrađen je ovaj mali sustav za upravljanje web sadržajem (CMS - Content management system).</p>
               
                <hr>

            </div>';

        include("sidebar.php");
		print '
        </div>
        <!-- /.row -->

        <hr>

    </div>';
	
	
?>