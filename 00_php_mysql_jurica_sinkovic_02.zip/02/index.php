<?php 
include ("include/dbconn.php");
include("header.php");
include("menu.php");

	# Početna
	if (!isset($_GET['menu']) || $_GET['menu'] == 1) { include("pocetna.php"); }
	
	# Novosti
	else if ($_GET['menu'] == 2) { include("novosti.php"); }
	
	# Kontakt
	else if ($_GET['menu'] == 3) { include("kontakt.php"); }
	
	# O nama
	else if ($_GET['menu'] == 4) { include("o-nama.php"); }
	
	# Galerija
	else if ($_GET['menu'] == 5) { include("galerija.php"); }
	
	
include("footer.php");

?>