<?php 

print '
	<!-- Blog Sidebar Widgets Column -->
    <div class="col-md-4">

		<!-- Blog Search Well -->
		<div class="well">
			<h4>Pretražite</h4>
			<div class="input-group">
				<input type="text" class="form-control">
				<span class="input-group-btn">
					<button class="btn btn-default" type="button">
						<span class="glyphicon glyphicon-search"></span>
					</button>
				</span>
			</div>
		</div>

        <!-- Blog Categories Well -->
            <div class="well">
                <h4>Kategorije</h4>
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="list-unstyled">
                            <li><a href="#">Intervencije</a>
                            </li>
                            <li><a href="#">Operativne vježbe</a>
                            </li>
                            <li><a href="#">Natjecateljske vježbe</a>
                            </li>
                            <li><a href="#">Ostalo</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

         <!-- Side Widget Well -->
            <div class="well">
                <h4>Obavijesti</h4>
                
				<p>Sva važnija događanja biti će prikazna ovdje.</p>
            </div>

    </div>';
?>