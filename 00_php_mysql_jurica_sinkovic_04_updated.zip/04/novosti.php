<?php 

print '
	<!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">
			
			<h1 class="page-header">Novosti<br></h1>';
				
			if (isset($action) && $action != '') {
				$query  = "SELECT * FROM news";
				$query .= " WHERE id=" . $_GET['action'];
				$result = @mysqli_query($MySQL, $query);
				$row = @mysqli_fetch_array($result);
				
				print '
                
                <h3>' . $row['title'] . '</h3>
				
                <p><span class="glyphicon glyphicon-time"></span><time datetime="' . $row['date'] . '">' . pickerDateToMysql($row['date']) . '</time></p>
				
                 <img src="images/' . $row['picture'] . '" alt="' . $row['title'] . '" title="' . $row['title'] . '"><br>
				 
                <p>' . $row['description'] . '</p>

				';
				}
				
			else {
				$query  = "SELECT * FROM news";
				$query .= " WHERE archive='N'";
				$query .= " ORDER BY date DESC";
				$result = @mysqli_query($MySQL, $query);
				while($row = @mysqli_fetch_array($result)) {
					print '
				<h3>' . $row['title'] . '</h3>
				
				<p><span class="glyphicon glyphicon-time"></span><time datetime="' . $row['date'] . '">' . pickerDateToMysql($row['date']) . '</time></p>
				
				 <img src="images/' . $row['picture'] . '" alt="' . $row['title'] . '" title="' . $row['title'] . '"><br>';
				 
				if(strlen($row['description']) > 300) {
					echo substr(strip_tags($row['description']), 0, 300).'... <a href="index.php?menu=' . $menu . '&amp;action=' . $row['id'] . '">Više<span class="glyphicon glyphicon-chevron-right"></span></a>';
				} else {
					echo strip_tags($row['description']);
				}
				print '
				<hr>';
				}
			}
			print '
			</div>';
				
        include("sidebar.php");
		print '
        </div>
        <!-- /.row -->

        <hr>

    </div>';

	
	
?>