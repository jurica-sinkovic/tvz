<?php 

	if(isset($_POST['email'])) {
	 
		// treba istestirati na live serveru ili mijenjati postavke na loclahostu: 
		//https://www.phpflow.com/php/how-to-send-email-from-localhost-using-php/
		
		$email_to = "jsinkovic@tvz.hr";
		$email_subject = "NTPWS - kontakt obrazac";
	 
		function died($error) {
			// your error code can go here
			print '<div class="alert alert-danger">Žao nam je, ali došlo je do greške prilikom slanja podataka.</div>';
			
			print '<div class="alert alert-info">' . $error . '<br></div>';
			die();
		}
	 
		// validacija da li postoje podaci
		if(!isset($_POST['firstname']) ||
			!isset($_POST['lastname']) ||
			!isset($_POST['email']) ||
			!isset($_POST['country']) ||
			!isset($_POST['comments'])) {
			died('Potrebno je konfigurirati localhost.');       
		}
	 
		$firstname = $_POST['firstname']; // required
		$lastname = $_POST['lastname']; // required
		$email_from = $_POST['email']; // required
		$country = $_POST['country']; // required
		$message = $_POST['message']; // required
	 
		$error_message = "";
		$email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
	 
	  if(!preg_match($email_exp,$email_from)) {
		$error_message .= 'Email adresa je neispravna.<br />';
	  }
	 
		$string_exp = "/^[A-Za-z .'-]+$/";
	 
	  if(!preg_match($string_exp,$firstname)) {
		$error_message .= 'Ime koje ste unjeli sadrži nedopuštene znakove.<br />';
	  }
	 
	  if(!preg_match($string_exp,$lastname)) {
		$error_message .= 'Prezime koje ste unjeli sadrži nedopuštene znakove.<br />';
	  }
	 
	  if(strlen($message) < 5) {
		$error_message .= 'Poruka mora biti duža od 5 znakova.<br />';
	  }
	 
	  if(strlen($error_message) > 0) {
		died($error_message);
	  }
	 
		$email_message = "Unjeli ste slijedeće podatke:\n\n";
	 
		 
		function clean_string($string) {
		  $bad = array("content-type","bcc:","to:","cc:","href");
		  return str_replace($bad,"",$string);
		}
	 
		 
	 
		$email_message .= "Ime: ".clean_string($firstname)."\n";
		$email_message .= "Prezime: ".clean_string($lastname)."\n";
		$email_message .= "Email: ".clean_string($email_from)."\n";
		$email_message .= "Država: ".clean_string($country)."\n";
		$email_message .= "Poruka: ".clean_string($message)."\n";
	 
	// create email headers
	$headers = 'Od: '.$email_from."\r\n".
	'Odgovorite na: '.$email_from."\r\n" .
	'X-Mailer: PHP/' . phpversion();
	@mail($email_to, $email_subject, $email_message, $headers);  
	?>
	  
		<div class="alert alert-success">
			<strong>Uspjeh!</strong> Vaša poruka je uspješno poslana.
		</div>
	 
	<?php
	 
	}
	?>

<?php
	print '
	
	<!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">
                  <h1 class="page-header">Kontakt<br>
                    <small>Ukoliko nas želite kontaktirati, ispunite dolje navedni obrazac.</small>
                </h1>

                <!-- Mapa -->  
                <div>
                    <div class="panel panel-default">
                        <div class="panel-body text-center">
                            <h4>VZO Krapinske Toplice</h4>
                                <div>
                                Ljudevita Gaja 27,<br />
                                49217 Krapinske Toplice<br />
                                Tel/fax: 049/234-233<br />
                                Email: <a href="mailto:vzokt@vzokt.hr">vzokt@vzokt.hr</a><br />
                                Web: <a href="http://www.vzokt.hr/">http://www.vzokt.hr/</a><br />
                                </div>

                            <hr />

                            <div class="map-responsive">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2766.760388293711!2d15.835546115931859!3d46.095753379113454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4765eb9079903657%3A0x5e3ab9e0102a8811!2sDVD+Krapinske+Toplice!5e0!3m2!1shr!2shr!4v1539717026561" width="700" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div>

                        </div>
                    </div>
                </div>

                

                <!-- Kontakt obrazac -->
               
                <div class="well well-sm">
                <form id="kontakt" method="post" action="" class="form-horizontal">
                    <fieldset>
                        <legend class="text-center header">Kontaktirajte nas</legend>
                        <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>Ime*:</p>
                                <input id="firstname" name="firstname" type="text" placeholder="Vaše ime" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>Prezime*:</p>
                                <input id="lastname" name="lastname" type="text" placeholder="Vaše prezime" class="form-control" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>E-mail*:</p>
                                <input id="email" name="email" type="email"  aria-describedby="emailHelp" placeholder="Vaš e-mail" class="form-control" required>
                            </div>
                        </div>

                          <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                            <p>Odaberite iz koje ste države:</p>
							
                            <select name="country" class="form-control" required>
											 <option value="">Država</option>';
											  $query  = "SELECT * FROM countries";
												$result = @mysqli_query($MySQL, $query);
												while($row = @mysqli_fetch_array($result)) {
													print '<option value="' . $row['country_code'] . '">' . $row['country_name'] . '</option>';
												}
											print '
                            </select>
                            </div>
                        </div>

                         

                        <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>Unesite željenu poruku:</p>
                                <textarea class="form-control" id="message" name="message" placeholder="Vaša poruka" rows="7" required></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary btn-lg">Pošalji</button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
		</div>';

        include("sidebar.php");
		print '
        </div>
        <!-- /.row -->

        <hr>

    </div>';
	
	
?>