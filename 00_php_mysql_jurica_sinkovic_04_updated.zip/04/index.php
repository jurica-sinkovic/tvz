<?php 

	# Stop Hacking attempt
	define('__APP__', TRUE);

	# Start session
	session_start();
		
	include("include/dbconn.php");
		
	# Variables MUST BE INTEGERS
    if(isset($_GET['menu'])) { $menu   = (int)$_GET['menu']; }
	if(isset($_GET['action'])) { $action   = (int)$_GET['action']; }
	
	# Variables MUST BE STRINGS A-Z
    if(!isset($_POST['_action_']))  { $_POST['_action_'] = FALSE;  }
	
	if (!isset($menu)) { $menu = 1; }
	
	# Classes & Functions
    include_once("include/funkcije.php");
	
	include("header.php");
	
	print '
	<header>
		<div'; 
			if ($menu > 1) { print ' class="pocetna-mala"'; } else { print ' class="pocetna-velika"'; }  print '>
		</div>';
		include("menu.php");
	
	print '
	</header>
	<main>';
	
		if (isset($_SESSION['message'])) {
			print $_SESSION['message'];
			unset($_SESSION['message']);
		}
		
		# Početna
		if (!isset($menu) || $menu == 1) { include("pocetna.php"); }
		
		# Novosti
		else if ($menu == 2) { include("novosti.php"); }
		
		# Kontakt
		else if ($menu == 3) { include("kontakt.php"); }
		
		# O nama
		else if ($menu == 4) { include("o-nama.php"); }
		
		# Galerija
		else if ($menu == 5) { include("galerija.php"); }
		
		# Registacija
		else if ($menu == 6) { include("registracija.php"); }
		
		# Prijava
		else if ($menu == 7) { include("prijava.php"); }
		
		# Admin 
		else if ($menu == 8) { include("admin.php"); }
		
	print '
	</main>';
	include("footer.php");

?>