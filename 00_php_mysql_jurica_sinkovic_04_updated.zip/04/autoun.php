<?php 

$_POST['firstname'] = "ter";
$_POST['lastname'] = "est";


function username_full(){
include "include/dbconn.php";
if((isset($_POST['firstname']) && $_POST['firstname']!="") || (isset($_POST['lastname']) && $_POST['lastname']!="")){
						
	$un_fn = $_POST['firstname'];
	$un_ln = $_POST['lastname'];
	$un_fn1 = substr($un_fn, 0 , 1 );

	$un_full = $un_fn1 . '' . $un_ln;
	$un_full = mb_strtolower($un_full, 'UTF-8');
	//echo $un_full . "<br>";

	$sql = "SELECT COUNT(username) AS 'count' FROM users WHERE username LIKE '$un_full%'";
	$result = mysqli_query($MySQL, $sql) or die(mysqli_error($MySQL));
	$num = mysqli_fetch_array($result);
	$count = $num['count'];
	if ($count > 0) {
		 $un_full = $un_full.$count;
		 echo $un_full;
	} else{	
		echo $un_full;
	}
	}
}

echo username_full();
?>