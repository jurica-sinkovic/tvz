<?php 
	
	# Update user profile
	if (isset($_POST['edit']) && $_POST['_action_'] == 'TRUE') {
		$query  = "UPDATE users SET firstname='" . $_POST['firstname'] . "', lastname='" . $_POST['lastname'] . "', dob='" . $_POST['dob'] . "', email='" . $_POST['email'] . "', username='" . $_POST['username'] . "', country='" . $_POST['country'] . "', city='" . $_POST['city'] . "', street='" . $_POST['street'] . "', role='" . $_POST['role'] . "'";
        $query .= " WHERE id=" . (int)$_POST['edit'];
        $query .= " LIMIT 1";
        $result = @mysqli_query($MySQL, $query);
		# Close MySQL connection
		@mysqli_close($MySQL);
		
		$_SESSION['message'] = '<div class="alert alert-success"><strong>Uspješno</strong> ste uredili profil.</div>';
		
		# Redirect
		header("Location: index.php?menu=8&action=1");
	}
	# End update user profile
	
	# Delete user profile
	if (isset($_GET['delete']) && $_GET['delete'] != '') {
	
		$query  = "DELETE FROM users";
		$query .= " WHERE id=".(int)$_GET['delete'];
		$query .= " LIMIT 1";
		$result = @mysqli_query($MySQL, $query);

		$_SESSION['message'] = '<div class="alert alert-info">Profil je uspješno <strong>obrisan</strong>.</div>';
		
		# Redirect
		header("Location: index.php?menu=8&action=1");
	}
	# End delete user profile
	
	
	#Show user info
	if (isset($_GET['id']) && $_GET['id'] != '') {
		$query  = "SELECT * FROM users";
		$query .= " WHERE id=".$_GET['id'];
		$result = @mysqli_query($MySQL, $query);
		$row = @mysqli_fetch_array($result);
		print '
		<div class="well well-sm">
			 <legend class="text-center header">Korisnički profil</legend>
			<p><b>Ime:</b> ' . $row['firstname'] . '</p>
			<p><b>Prezime:</b> ' . $row['lastname'] . '</p>
			<p><b>Datum rođenja:</b> ' . pickerDate($row['dob']) . '</p>
			<p><b>E-mail:</b> ' . $row['email'] . '</p>
			<p><b>Korisničko ime:</b> ' . $row['username'] . '</p>';
			$_query  = "SELECT * FROM countries";
			$_query .= " WHERE country_code='" . $row['country'] . "'";
			$_result = @mysqli_query($MySQL, $_query);
			$_row = @mysqli_fetch_array($_result);
			print '
			<p><b>Država:</b> ' .$_row['country_name'] . '</p>
			<p><b>Grad:</b> ' . $row['city'] . '</p>
			<p><b>Ulica:</b> ' . $row['street'] . '</p>';
			$_query  = "SELECT * FROM roles";
			$_query .= " WHERE id='" . $row['role'] . "'";
			$_result = @mysqli_query($MySQL, $_query);
			$_row = @mysqli_fetch_array($_result);
			print '
			<p><b>Uloga korisnika:</b> ' .$_row['name'] . '</p>
			<p><b>Datum i vrijeme zadnjeg ažuriranja:</b> ' . pickerDateToMysql($row['date']) . '</p><br>
			<button type="button" class="btn btn-primary btn-lg" onclick="history.back();">Nazad</button>
		</div>';
	}
	#Edit user profile
	else if (isset($_GET['edit']) && $_GET['edit'] != '') {
		$query  = "SELECT * FROM users";
		$query .= " WHERE id=".$_GET['edit'];
		$result = @mysqli_query($MySQL, $query);
		$row = @mysqli_fetch_array($result);
		$checked_archive = false;
		
		print '
		<div class="well well-sm">
				<form action="" id="registration_form" name="registration_form" class="form-horizontal" method="POST">
				<input type="hidden" id="_action_" name="_action_" value="TRUE">
				<input type="hidden" id="edit" name="edit" value="' . $_GET['edit'] . '">
			
                    <fieldset>
                        <legend class="text-center header">Uredi korisnički profil</legend>
                        <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>Ime*:</p>
                                <input type="text" id="firstname" name="firstname" value="' . $row['firstname'] . '" placeholder="Vaše ime" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>Prezime*:</p>
                                <input type="text" id="lastname" name="lastname" value="' . $row['lastname'] . '" placeholder="Vaše prezime" required>
                            </div>
                        </div>
						
						 <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>Datum rođenja*:</p>
                                <input type="date" id="dob" name="dob" value="' . $row['dob'] . '" placeholder="Vaš datum rođenja" required>
                            </div>
                        </div>
						
												
                        <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>E-mail*:</p>
                                <input type="email" id="email" name="email"  value="' . $row['email'] . '" placeholder="Vaš e-mail" required>
                            </div>
                        </div>
												
						  <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>Korisničko ime*:</p>
                                <input type="text" id="username" name="username" value="' . $row['username'] . '" placeholder="Vaše korisničko ime" required><br>
                            </div>
                        </div>
						
                          <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                            <p>Država*:</p>
						<select name="country" id="country">
							<option value="">***odaberite***</option>';
							$_query  = "SELECT * FROM countries";
							$_result = @mysqli_query($MySQL, $_query);
							while($_row = @mysqli_fetch_array($_result)) {
								print '<option value="' . $_row['country_code'] . '"';
								if ($row['country'] == $_row['country_code']) { print ' selected'; }
								print '>' . $_row['country_name'] . '</option>';
							}
						print '
						</select>
                            </div>
                        </div>
						
						<div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>Grad:</p>
                                <input type="text" id="city" name="city" value="' . $row['city'] . '" placeholder="Vaš grad"><br>
                            </div>
                        </div>
						
						<div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>Ulica:</p>
                                <input type="text" id="street" name="street" value="' . $row['street'] . '" placeholder="Vaša ulica"><br>
                            </div>
                        </div>
						
						
						 <div class="form-group">
                            <div class="col-md-10 col-md-offset-1">
                                <p>Uloga korisnika*:</p>
                               <select name="role" id="role">
							<option value="">***odaberite***</option>';
							$_query  = "SELECT * FROM roles";
							$_result = @mysqli_query($MySQL, $_query);
							while($_row = @mysqli_fetch_array($_result)) {
								print '<option value="' . $_row['id'] . '"';
								if ($row['role'] == $_row['id']) { print ' selected'; }
								print '>' . $_row['name'] . '</option>';
							}
						print '
						</select>
                            </div>
                        </div>
						
						<div class="form-group">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary btn-lg">Ažuriraj</button>
								<button type="button" class="btn btn-primary btn-lg" onclick="history.back();">Nazad</button>
                            </div>
                        </div>

                    </fieldset>
                </form>
            </div>';
	}
	else {
		print '
		<h2 class="page-header">Korisnici</h2>
		<div>
			<table>
				<thead>
					<tr>
						<th>Pregledaj</th>
						<th>Uredi</th>
						<th>Obriši</th>
						<th>Ime</th>
						<th>Prezime</th>
						<th>E-mail</th>
						<th>Korisničko ime</th>
						<th>Uloga</th>
						<th>Novi</th>
					</tr>
				</thead>
				<tbody>';
				$query  = "SELECT * FROM users";
				$result = @mysqli_query($MySQL, $query);
				while($row = @mysqli_fetch_array($result)) {
					print '
					<tr>
						<td><a href="index.php?menu='.$menu.'&amp;action='.$action.'&amp;id=' .$row['id']. '"><span class="glyphicon glyphicon-user"></span></a></td>
						<td><a href="index.php?menu='.$menu.'&amp;action='.$action.'&amp;edit=' .$row['id']. '"><span class="glyphicon glyphicon-edit"></span></a></td>
						<td><a href="index.php?menu='.$menu.'&amp;action='.$action.'&amp;delete=' .$row['id']. '"><span class="glyphicon glyphicon-remove"></span></a></td>
						<td>' . $row['firstname'] . '</td>
						<td>' . $row['lastname'] . '</td>
						<td>' . $row['email'] . '</td>
						<td>' . $row['username'] . '</td>
						<td>';
							$_query  = "SELECT * FROM roles";
							$_query .= " WHERE id='" . $row['role'] . "'";
							$_result = @mysqli_query($MySQL, $_query);
							$_row = @mysqli_fetch_array($_result, MYSQLI_ASSOC);
							print $_row['name'] . '
						</td>
						<td>';
							if ($row['role'] > 0) { print '<span class="glyphicon glyphicon-remove"></span>'; }
                            else if ($row['role'] == 0) { print '<span class="glyphicon glyphicon-ok"></span>'; }
						print '
						</td>
					</tr>';
				}
			print '
				</tbody>
			</table>
		</div>';
	}
	
	# Close MySQL connection
	@mysqli_close($MySQL);
	
?>