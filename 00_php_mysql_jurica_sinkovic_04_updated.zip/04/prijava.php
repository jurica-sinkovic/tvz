<?php 
	if ($_POST['_action_'] == FALSE) {
		print '
	
	<!-- Page Content -->
    <div class="container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="text-center">


							<h3><i class="fa fa-user fa-4x"></i></h3>
							<h2 class="text-center">Prijava</h2>
							<div class="panel-body">
								
								<form action="" name="myForm" id="myForm" method="POST">
								<input type="hidden" id="_action_" name="_action_" value="TRUE">
								<input type="hidden" id="role" name="role" value="TRUE">

									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-user color-blue"></i></span>

											<input name="username" type="text" class="form-control" placeholder="Unesite korisničko ime" required>
										</div>
									</div>

									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="glyphicon glyphicon-lock color-blue"></i></span>
											
											<input name="password" type="password" class="form-control" placeholder="Unesite lozinku" required>
										</div>
									</div>

									<div class="form-group">

										<input name="login" class="btn btn-lg btn-primary btn-block" value="Prijavi se" type="submit">
									</div>


								</form>
				
							</div>';
							
				
				}
					else if ($_POST['_action_'] == TRUE) {
						
						$query  = "SELECT * FROM users";
						$query .= " WHERE username='" .  $_POST['username'] . "'";
						$result = @mysqli_query($MySQL, $query);
						$row = @mysqli_fetch_array($result, MYSQLI_ASSOC);
						
						if (password_verify($_POST['password'], $row['password'])) {
							#password_verify https://secure.php.net/manual/en/function.password-verify.php
							$_SESSION['user']['valid'] = 'true';
							$_SESSION['user']['id'] = $row['id'];
							$_SESSION['user']['firstname'] = $row['firstname'];
							$_SESSION['user']['lastname'] = $row['lastname'];
							$_SESSION['user']['role'] = $row['role'];
							$_SESSION['message'] = '<div class="alert alert-success">Dobrodošli, <strong>' . $_SESSION['user']['firstname'] . ' ' . $_SESSION['user']['lastname'] . '</strong>.</div>';
							# Redirect to admin website

							header("Location: index.php?menu=8");
						}
						
						# Bad username or password
						else {
							unset($_SESSION['user']);
							$_SESSION['message'] = '<div class="alert alert-danger">Unjeli ste <strong>pogrešno</strong> korisničko ime ili lozinku!</div>';
							header("Location: index.php?menu=7");
						}
					}
				print '

						</div>
					</div> <!-- End panel Body-->
				</div>
			</div>
		</div>
		<hr>	
	</div>';
	
?>