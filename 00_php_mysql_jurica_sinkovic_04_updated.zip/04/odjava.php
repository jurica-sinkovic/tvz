<?php
	# Stop Hacking attempt
    define('__APP__', TRUE);

	# Start session
	session_start();
	
	
	unset($_POST);
	unset($_SESSION['user']);

	$_SESSION['user']['valid'] = 'false';
	$_SESSION['message'] = '<div class="alert alert-info"><strong>Odjavili ste se</strong> ili <strong>nemate odgovarajuću razinu pristupa</strong> koju vam mora odobriti administrator.</div>';
	
	header("Location: index.php?menu=1");
	exit;